import React, { useState, useEffect } from 'react';
import API, { setToken } from './api';
import Signup from './components/Signup';
import Login from './components/Login';
import Feed from './components/Feed';

export default function App() {
  const [token, setTokenState] = useState(localStorage.getItem('token') || null);
  const [user, setUser] = useState(null);

  useEffect(() => setToken(token), [token]);

  const onAuth = ({ token, user }) => {
    localStorage.setItem('token', token);
    setTokenState(token);
    setUser(user);
  };

  if (!token) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Match Clone — Login or Sign up</h2>
        <Login onAuth={onAuth} />
        <hr />
        <Signup onAuth={onAuth} />
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Welcome {user?.name || ''}</h2>
      <Feed />
    </div>
  );
}