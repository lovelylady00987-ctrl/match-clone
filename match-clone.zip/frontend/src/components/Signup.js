import React, { useState } from 'react';
import API from '../api';

export default function Signup({ onAuth }) {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const submit = async e => {
    e.preventDefault();
    try {
      const { data } = await API.post('/auth/signup', form);
      onAuth(data);
    } catch (err) {
      alert(err.response?.data?.message || 'Signup failed');
    }
  };
  return (
    <form onSubmit={submit}>
      <h3>Sign Up</h3>
      <input placeholder="Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
      <input placeholder="Email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
      <input type="password" placeholder="Password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
      <button type="submit">Sign up</button>
    </form>
  );
}