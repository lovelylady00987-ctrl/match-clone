import React from 'react';

export default function ProfileCard({ profile }) {
  if (!profile) return <div>No profile found</div>;
  return (
    <div style={{ border: '1px solid #ccc', borderRadius: 10, padding: 16, textAlign: 'center' }}>
      <h3>{profile.name} {profile.age ? `(${profile.age})` : ''}</h3>
      <p>{profile.bio || 'No bio'}</p>
      <p><small>{profile.location}</small></p>
      <div>
        {profile.interests?.map(i => (
          <span key={i} style={{ margin: 4, border: '1px solid #ccc', padding: 4, borderRadius: 6 }}>{i}</span>
        ))}
      </div>
    </div>
  );
}