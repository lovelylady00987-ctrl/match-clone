import React, { useEffect, useState } from 'react';
import API from '../api';
import ProfileCard from './ProfileCard';

export default function Feed() {
  const [profile, setProfile] = useState(null);
  const [message, setMessage] = useState('');

  const loadNext = async () => {
    const { data } = await API.get('/profiles/next');
    setProfile(data.profile);
    setMessage(data.message || '');
  };

  useEffect(() => { loadNext(); }, []);

  const act = async action => {
    if (!profile) return;
    const { data } = await API.post('/profiles/action', { targetId: profile._id, action });
    alert(data.message);
    loadNext();
  };

  if (!profile) return <div>{message || 'No more profiles'}</div>;

  return (
    <div>
      <ProfileCard profile={profile} />
      <div style={{ marginTop: 10 }}>
        <button onClick={() => act('skip')}>Skip</button>
        <button onClick={() => act('like')}>Like</button>
      </div>
    </div>
  );
}