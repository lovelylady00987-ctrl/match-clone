const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');

router.get('/next', auth, async (req, res) => {
  const me = await User.findById(req.user.id).lean();
  if (!me) return res.status(404).json({ message: 'User not found' });
  const excluded = [me._id, ...me.likes, ...me.skips, ...me.matches];
  const candidate = await User.findOne({ _id: { $nin: excluded } }).select('-passwordHash').lean();
  if (!candidate) return res.json({ profile: null, message: 'No more profiles' });
  res.json({ profile: candidate });
});

router.post('/action', auth, async (req, res) => {
  const { targetId, action } = req.body;
  const me = await User.findById(req.user.id);
  const target = await User.findById(targetId);
  if (action === 'skip') {
    if (!me.skips.includes(target._id)) me.skips.push(target._id);
    await me.save();
    return res.json({ message: 'Skipped' });
  }
  if (action === 'like') {
    if (!me.likes.includes(target._id)) me.likes.push(target._id);
    if (!target.likedBy.includes(me._id)) target.likedBy.push(me._id);
    const isMatch = target.likes.some(id => id.toString() === me._id.toString());
    if (isMatch) {
      me.matches.push(target._id);
      target.matches.push(me._id);
    }
    await me.save();
    await target.save();
    res.json({ message: isMatch ? 'Matched' : 'Liked', match: isMatch });
  }
});

router.get('/matches', auth, async (req, res) => {
  const me = await User.findById(req.user.id).populate('matches', '-passwordHash');
  res.json({ matches: me.matches || [] });
});

module.exports = router;