module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || "supersecretjwt",
  MONGO_URI: process.env.MONGO_URI || "mongodb://127.0.0.1:27017/match_clone",
  PORT: process.env.PORT || 4000
};